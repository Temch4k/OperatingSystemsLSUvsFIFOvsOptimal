-In order to run the program first you have to make it
			by typing- make 
			in the folder of the folder of the program

-Then, to run it, you will type- ./sched <frameSize> <inputFileName> <outputFileName>
			example: ./sched 128 pg-reference.txt bob.txt

-FIFO and LRU takes a few seconds to run, optimal takes a much longer timer therefore I made it so it prints what percentage we are at
-File bob.txt simply has the output of the program that was ran 4 different times with 4 differetn frame sizes